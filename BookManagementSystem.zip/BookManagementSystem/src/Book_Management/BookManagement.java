package Book_Management;

import java.sql.*;
import java.util.Scanner;

public class BookManagement{
    private static final String DATABASE_URL = "com.mysql.cj.jdbc.Driver";
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        createTable();
        while (true) {
            System.out.println("1. Add a book");
            System.out.println("2. List all books");
            System.out.println("3. Update a book");
            System.out.println("4. Delete a book");
            System.out.println("5. Search for a book");
            System.out.println("6. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1: addBook(); break;
                case 2: listBooks(); break;
                case 3: updateBook(); break;
                case 4: deleteBook(); break;
                case 5: searchBook(); break;
                case 6: System.exit(0);
                default: System.out.println("Invalid option. Try again.");
            }
        }
    }

    private static void createTable() {
        try{
            Conn conn=new Conn();
            String query= "CREATE TABLE IF NOT EXISTS books (" +
                    "id int auto_increment primary key, " +
                    "title TEXT NOT NULL, " +
                    "author TEXT NOT NULL, " +
                    "year INT, " +
                    "price REAL)";
            conn.s.executeUpdate(query);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void addBook() {
        System.out.print("Enter title: ");
        String title = scanner.nextLine();
        System.out.print("Enter author: ");
        String author = scanner.nextLine();
        System.out.print("Enter year: ");
        int year = scanner.nextInt();
        System.out.print("Enter price: ");
        double price = scanner.nextDouble();
        scanner.nextLine(); // Consume newline


        try {
           Conn conn=new Conn();
            String query = "INSERT INTO books(title, author, year, price) VALUES(?, ?, ?, ?)";
           PreparedStatement pstmt = conn.c.prepareStatement(query);
            pstmt.setString(1, title);
            pstmt.setString(2, author);
            pstmt.setInt(3, year);
            pstmt.setDouble(4, price);
            pstmt.executeUpdate();
            System.out.println("Book added successfully!");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void listBooks() {

        try
         {
             Conn conn=new Conn();
             String query = "SELECT * FROM books";
            Statement stmt = conn.c.createStatement();
             ResultSet rs = stmt.executeQuery(query);
            System.out.println("ID | Title | Author | Year | Price");
            while (rs.next()) {
                System.out.println(rs.getInt("id") + " | " +
                        rs.getString("title") + " | " +
                        rs.getString("author") + " | " +
                        rs.getInt("year") + " | " +
                        rs.getDouble("price"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void updateBook() {
        System.out.print("Enter book ID to update: ");
        int id = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        System.out.print("Enter new title: ");
        String title = scanner.nextLine();
        System.out.print("Enter new author: ");
        String author = scanner.nextLine();
        System.out.print("Enter new year: ");
        int year = scanner.nextInt();
        System.out.print("Enter new price: ");
        double price = scanner.nextDouble();
        scanner.nextLine(); // Consume newline


        try {
            Conn conn=new Conn();
            String query = "UPDATE books SET title = ?, author = ?, year = ?, price = ? WHERE id = ?";
            PreparedStatement pstmt = conn.c.prepareStatement(query);
            pstmt.setString(1, title);
            pstmt.setString(2, author);
            pstmt.setInt(3, year);
            pstmt.setDouble(4, price);
            pstmt.setInt(5, id);
            int rowsUpdated = pstmt.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Book updated successfully!");
            } else {
                System.out.println("Book not found.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void deleteBook() {
        System.out.print("Enter book ID to delete: ");
        int id = scanner.nextInt();
        scanner.nextLine(); // Consume newline


        try {
            Conn conn=new Conn();
            String query = "DELETE FROM books WHERE id = ?";
            PreparedStatement pstmt = conn.c.prepareStatement(query);
            pstmt.setInt(1, id);
            int rowsDeleted = pstmt.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("Book deleted successfully!");
            } else {
                System.out.println("Book not found.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void searchBook() {
        System.out.print("Enter title or author to search: ");
        String keyword = scanner.nextLine();


        try {
            Conn conn=new Conn();
            String query = "SELECT * FROM books WHERE title LIKE ? OR author LIKE ?";
            PreparedStatement pstmt = conn.c.prepareStatement(query);
            pstmt.setString(1, "%" + keyword + "%");
            pstmt.setString(2, "%" + keyword + "%");
            ResultSet rs = pstmt.executeQuery();

            System.out.println("ID | Title | Author | Year | Price");
            while (rs.next()) {
                System.out.println(rs.getInt("id") + " | " +
                        rs.getString("title") + " | " +
                        rs.getString("author") + " | " +
                        rs.getInt("year") + " | " +
                        rs.getDouble("price"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

